#!/bin/bash
###############################################################################
# Sample script to:
#  - Read parameters from /tmp/variabili.txt
#  - Check dependencies (jq, openssl)
#  - Create destination directories if missing
#  - Authenticate with Managed Identity (both Azure ARC and Azure VM)
#  - Download a Key Vault secret in PFX format
#  - Extract .cer and .key
#  - Calculate thumbprint and copy files only if the certificate has changed
###############################################################################

############################################
# 1. Error handling function
############################################
handle_error() {
  echo "Error: $1" >&2
  exit 1
}

############################################
# 2. Reading variables from file
############################################
CONFIG_FILE="/clc/variables.txt"
if [ -f "$CONFIG_FILE" ]; then
  while IFS= read -r line
  do
      eval "$line"
  done < "$CONFIG_FILE"
else
  handle_error "Configuration file $CONFIG_FILE not found."
fi

############################################
# 3. Checking dependencies
############################################
command -v jq >/dev/null 2>&1 || handle_error "jq is not installed. Install with 'sudo dnf install jq'"
command -v openssl >/dev/null 2>&1 || handle_error "OpenSSL is not installed. Install with 'sudo dnf install openssl'"

############################################
# 4. Setting default variables (if not already defined)
############################################
RESOURCE_URL="${RESOURCE_URL:-https://vault.azure.net}"
# The API version can be specified in the configuration file, e.g.
API_VERSION="${API_VERSION:-2018-02-01}"
KEYVAULT_NAME="${KEYVAULT_NAME:-$KEYVAULT_NAME}"
CERT_SECRET_NAME="${CERT_SECRET_NAME:-$CERT_NAME}"
KEYVAULT_API_VERSION="${KEYVAULT_API_VERSION:-7.2}"

# Temporary/Final paths
CERT_PATH="${CERT_PATH:-/tmp/cert}"
KEY_PATH="${KEY_PATH:-/tmp/key}"
TEMP_PATH="${TEMP_PATH:-/tmp}"

CERT_OUTPUT_DIR="${CERT_OUTPUT_DIR:-/etc/pki/tls/certs}"
KEY_OUTPUT_DIR="${KEY_OUTPUT_DIR:-/etc/pki/tls/private}"

# Default permissions
CERT_PERMISSIONS="${CERT_PERMISSIONS:-0644}"
KEY_PERMISSIONS="${KEY_PERMISSIONS:-0600}"

# Temporary files (all saved in TEMP_PATH)
PFX_TEMP_FILE="${TEMP_PATH}/${CERT_NAME}.pfx"
CER_TEMP_FILE="${CERT_PATH}/${CERT_NAME}.cer"
KEY_TEMP_FILE="${KEY_PATH}/${CERT_NAME}.key"

############################################
# 5. Checking and creating directories
############################################
mkdir -p "$CERT_PATH" || handle_error "Unable to create $CERT_PATH"
mkdir -p "$KEY_PATH"  || handle_error "Unable to create $KEY_PATH"
mkdir -p "$TEMP_PATH" || handle_error "Unable to create $TEMP_PATH"

mkdir -p "$CERT_OUTPUT_DIR" || handle_error "Unable to create $CERT_OUTPUT_DIR"
mkdir -p "$KEY_OUTPUT_DIR"  || handle_error "Unable to create $KEY_OUTPUT_DIR"

############################################
# 6. Obtaining the access token via Managed Identity
############################################
# Encode the resource URL
ENCODED_RESOURCE=$(python3 -c "import urllib.parse; print(urllib.parse.quote('''${RESOURCE_URL}'''))")

# Define endpoints for Azure ARC and native VM
ARC_URL="http://127.0.0.1:40342/metadata/identity/oauth2/token?api-version=${API_VERSION}&resource=${ENCODED_RESOURCE}"
NATIVE_URL="http://169.254.169.254/metadata/identity/oauth2/token?api-version=${API_VERSION}&resource=${ENCODED_RESOURCE}"

# Try the ARC endpoint with a short timeout
ARC_RESPONSE=$(curl -s -D - -H "Metadata:true" --max-time 3 "$ARC_URL")

if echo "$ARC_RESPONSE" | grep -q "Www-Authenticate"; then
  echo "Azure ARC detected. Using ARC endpoint for token."
  # Extract challenge token path from header
  CHALLENGE_TOKEN_PATH=$(echo "$ARC_RESPONSE" | grep 'Www-Authenticate' | cut -d "=" -f 2 | tr -d "[:cntrl:]")
  if [ -z "$CHALLENGE_TOKEN_PATH" ]; then
    handle_error "Unable to retrieve the challenge token path from the ARC endpoint."
  fi
  CHALLENGE_TOKEN=$(cat "$CHALLENGE_TOKEN_PATH" 2>/dev/null)
  if [ -z "$CHALLENGE_TOKEN" ]; then
    handle_error "Unable to read the challenge token from the ARC endpoint. Check for root privileges."
  fi
  # Request the token using the obtained challenge token
  TOKEN_RESPONSE=$(curl -s -H "Metadata:true" -H "Authorization: Basic $CHALLENGE_TOKEN" "$ARC_URL")
  ACCESS_TOKEN=$(echo "$TOKEN_RESPONSE" | jq -r .access_token)
  if [ -z "$ACCESS_TOKEN" ] || [ "$ACCESS_TOKEN" == "null" ]; then
    handle_error "Unable to obtain the access token from the ARC endpoint."
  fi
  echo "Access token obtained via Azure ARC."
else
  echo "Azure ARC not available. Using the VM Managed Identity endpoint."
  TOKEN_RESPONSE=$(curl -s -H "Metadata:true" "$NATIVE_URL")
  ACCESS_TOKEN=$(echo "$TOKEN_RESPONSE" | jq -r .access_token)
  if [ -z "$ACCESS_TOKEN" ] || [ "$ACCESS_TOKEN" == "null" ]; then
    handle_error "Unable to obtain the access token from the VM."
  fi
  echo "Access token obtained via Azure VM."
fi

############################################
# 7. Downloading the secret (PFX) from the Key Vault
############################################
SECRET_URL="https://${KEYVAULT_NAME}.vault.azure.net/secrets/${CERT_SECRET_NAME}?api-version=${KEYVAULT_API_VERSION}"
SECRET_RESPONSE=$(curl -s -H "Authorization: Bearer $ACCESS_TOKEN" "$SECRET_URL")

SECRET_CONTENT=$(echo "$SECRET_RESPONSE" | jq -r '.value')
if [ -z "$SECRET_CONTENT" ] || [ "$SECRET_CONTENT" == "null" ]; then
  echo "Response received from Key Vault:"
  echo "$SECRET_RESPONSE"
  handle_error "Secret not found or empty."
fi

# Decode base64 into a temporary .pfx file
echo "$SECRET_CONTENT" | base64 -d > "$PFX_TEMP_FILE" || handle_error "Decoding the secret (PFX) failed."
echo "PFX saved to: $PFX_TEMP_FILE"

############################################
# 8. Extracting the certificate (.cer) and key (.key)
############################################
# If the PFX has a password, specify it in PFX_PASSWORD
# For an empty password, use -passin pass:
openssl pkcs12 -in "$PFX_TEMP_FILE" -nokeys -out "$CER_TEMP_FILE" -passin pass:"$PFX_PASSWORD" || {
  echo "Warning: extraction of the certificate (.cer) failed."
  exit 1
}

openssl pkcs12 -in "$PFX_TEMP_FILE" -nocerts -nodes -out "$KEY_TEMP_FILE" -passin pass:"$PFX_PASSWORD" || {
  echo "Warning: extraction of the private key (.key) failed."
  exit 1
}

echo "Temporary certificate: $CER_TEMP_FILE"
echo "Temporary key:         $KEY_TEMP_FILE"

############################################
# 9. Calculating the thumbprint of the new certificate
############################################
NEW_CERT_THUMBPRINT=$(openssl x509 -noout -fingerprint -sha1 -in "$CER_TEMP_FILE" | cut -d'=' -f2 | tr -d ':')
echo "Thumbprint (new certificate): $NEW_CERT_THUMBPRINT"

############################################
# 10. Check if a local certificate already exists and calculate its thumbprint
############################################
LOCAL_CERT="${CERT_OUTPUT_DIR}/${CERT_NAME}.cer"
LOCAL_KEY="${KEY_OUTPUT_DIR}/${CERT_NAME}.key"

if [ -f "$LOCAL_CERT" ]; then
  OLD_CERT_THUMBPRINT=$(openssl x509 -noout -fingerprint -sha1 -in "$LOCAL_CERT" | cut -d'=' -f2 | tr -d ':')
  echo "Thumbprint (existing certificate): $OLD_CERT_THUMBPRINT"
else
  OLD_CERT_THUMBPRINT=""
fi

############################################
# 11. Compare thumbprints and copy if necessary
############################################
if [ -n "$OLD_CERT_THUMBPRINT" ] && [ "$NEW_CERT_THUMBPRINT" = "$OLD_CERT_THUMBPRINT" ]; then
  echo "The local certificate is already up-to-date (identical thumbprint)."
  # If needed, remove temporary files and exit
  rm -f "$PFX_TEMP_FILE" "$CER_TEMP_FILE" "$KEY_TEMP_FILE"
  exit 0
else
  echo "The certificate is different or does not exist; proceeding with copying..."

  cp -f "$CER_TEMP_FILE" "$LOCAL_CERT" || handle_error "Certificate copy failed."
  cp -f "$KEY_TEMP_FILE" "$LOCAL_KEY"   || handle_error "Key copy failed."

  chmod "$CERT_PERMISSIONS" "$LOCAL_CERT"
  chmod "$KEY_PERMISSIONS"  "$LOCAL_KEY"

  echo "New certificate installed at:"
  echo "  $LOCAL_CERT"
  echo "  $LOCAL_KEY"
fi

############################################
# 12. Final cleanup (optional)
############################################
rm -f "$PFX_TEMP_FILE" "$CER_TEMP_FILE" "$KEY_TEMP_FILE"
echo "Operation completed."

